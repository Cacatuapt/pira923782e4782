import{I as e}from"../vendor/pnpm/vant@4.9.21_vue@3.5.21_typescript@5.8.3_-w-uzHHh8.js";import{_ as p}from"../vendor/Header-C5XsFjk4.js";import{u as t,h as i,j as n,r,k as o}from"../index-D0g3Csae.js";import{u as s}from"../vendor/pnpm/vue-i18n@11.1.12_vue@3.5.21_typescript@5.8.3_-BGj22MEC.js";import{t as a,E as m,G as l,s as v,L as d,F as c,O as u}from"../vendor/pnpm/@vue_runtime-core@3.5.21-rCuj_X1G.js";import{p as _,M as j}from"../vendor/pnpm/@vue_shared@3.5.21-CVgPphJj.js";import{u as g}from"../vendor/pnpm/@vue_reactivity@3.5.21-BjvHxQop.js";import"../vendor/pnpm/@vant_use@1.6.0_vue@3.5.21_typescript@5.8.3_-C8hyWIvE.js";import"../vendor/pnpm/@vue_runtime-dom@3.5.21-fn2Hsx19.js";import"../vendor/pnpm/@vant_popperjs@1.3.0-DwV6nPjs.js";import"../vendor/pnpm/vue-router@4.5.1_vue@3.5.21_typescript@5.8.3_-CRSVo28B.js";import"../vendor/pnpm/axios@1.12.1-D7jkGkjL.js";import"../vendor/pnpm/tldts@7.4.0-C7KqUMFX.js";import"../vendor/pnpm/tldts-core@7.4.0-C7ujFBFb.js";import"../vendor/pnpm/@fingerprintjs_fingerprintjs@5.2.0-IOlpq988.js";import"../vendor/pnpm/decimal.js@10.6.0-de9prNx4.js";import"../vendor/pnpm/pinia@3.0.3_typescript@5.8.3_vue@3.5.21_typescript@5.8.3_-DKBbvF-m.js";import"../vendor/pnpm/socket.io-client@4.8.3-CZ7IjuAC.js";import"../vendor/pnpm/engine.io-client@6.6.4-CD_S0XcM.js";import"../vendor/pnpm/engine.io-parser@5.2.3-maM8BVJz.js";import"../vendor/pnpm/@socket.io_component-emitter@3.1.2-B7jhhhSB.js";import"../vendor/pnpm/socket.io-parser@4.2.5-Cgzri-Qj.js";import"../vendor/pnpm/pinia-plugin-persistedstate@4.5.0_pinia@3.0.3_typescript@5.8.3_vue@3.5.21_typescript@5.8.3__-C9XmJFZ0.js";import"../vendor/pnpm/destr@2.0.5-WfmzGWA8.js";import"../vendor/pnpm/deep-pick-omit@1.2.1-CDZeMyKV.js";import"../vendor/pnpm/amfe-flexible@2.2.1-BdYc3Utq.js";import"../vendor/pnpm/@intlify_core-base@11.1.12-TPOxhPpD.js";import"../vendor/pnpm/@intlify_shared@11.1.12-CnQzzIDU.js";import"../vendor/pnpm/@intlify_message-compiler@11.1.12-FvKX4h0U.js";const f={class:"lang_outer"},y={class:"lang_list"},k=["onClick"],x=["src"],h={class:"lang_title"},b=o(a({__name:"index",setup(o){const a=t(),{locale:b}=s(),C=[{title:"English",
// 英文
value:"en",icon:"en"},{title:"Portuguese",
// 葡萄牙语
value:"pt",icon:"pt"},{title:"Español",
// 西班牙语
value:"es",icon:"es"},{title:"हिन्दी",
// 印度语
value:"ind",icon:"ind"},{title:"Spanish",
// 巴西语
value:"pb",icon:"pb"},{title:"México",
// 墨西哥
value:"mx",icon:"mx"},{title:"Ecuador",value:"ec",icon:"ec"},{title:"Türkçe",
// 土耳其语
value:"tr",icon:"tr"},{title:"عربي",
// 阿拉伯语
value:"ar",icon:"ar"}];return(t,o)=>{const s=e;return l(),m("div",f,[v(p,{title:t.$t("language")},null,8,["title"]),d("div",y,[(l(),m(c,null,u(C,e=>d("div",{class:_(["lang_item",g(b)==e.value?"lang_item_active":""]),key:e.value,onClick:p=>{return t=e.value,b.value=t,a.language=t,n(t),void r.back();var t}},[d("img",{class:"lang_img",src:g(i)(),alt:"language"},null,8,x),d("div",h,j(e.title)+" - "+j(e.value.toUpperCase()),1),v(s,{name:"arrow",size:"16",color:"#999"})],10,k)),64))])])}}}),[["__scopeId","data-v-d7335030"]]);export{b as default};
